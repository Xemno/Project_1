package ch.ethz.inf.vs.a1.ankoller.antitheft;

import ch.ethz.inf.vs.a1.ankoller.antitheft.AlarmCallback;

import static java.lang.Math.abs;

public class SpikeMovementDetector extends AbstractMovementDetector {
    private int Alarmlogicnumber;

    public SpikeMovementDetector(AlarmCallback callback, int sensitivity) {
        super(callback, sensitivity);
        MainActivity ma= new MainActivity();
        Alarmlogicnumber=1;
    }

    public void setAlarmLogic (int n)
    { this.Alarmlogicnumber=n;}

    @Override
    public boolean doAlarmLogic(float[] values) {
		// TODO, insert your logic here
        //do case distinction if isAlarmlogic  ->sqrt, standardm special
       switch(Alarmlogicnumber){
           case 2:
               return secondAlarm(values);


           case 1:
           default:
               return standardAlarm(values);
       }
    }

    private boolean standardAlarm (float[]values){
        //spike detector
        //elementwise sum of absolute linear acceleration values exceeds sensitivity
        //threshold, movement is detected
        float sum=0;
        for(float i: values) sum=sum+abs(i);
        return sum>=(float) sensitivity;
    }

    private boolean secondAlarm(float []values) {
        float sum = 0;
        for (float i : values) sum = sum + abs(i) + 10;
        return sum >= (float) sensitivity;
    }






}
