package ch.ethz.inf.vs.a1.ankoller.antitheft;

import android.os.Bundle;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.support.v4.app.FragmentActivity;



public class SettingsActivity extends FragmentActivity{

    protected void onCreate (Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.preferences);


        //return the fragmentmanager for interacting with fragments associated with this activity
        //begintransaction: start of series of edit operations on the fragments associated with this FragmentManager

      getFragmentManager().beginTransaction().replace(R.id.preferences_frame, new PrefFragment()).commit();
                //replace(int containerViewId, Fragment fragment)
    }

    public static  class PrefFragment extends PreferenceFragment{
        private Bundle savedInstanceState;


        public void onCreate(Bundle savedInstanceState){
            super.onCreate(savedInstanceState);
            //load preferences from xml resource
            addPreferencesFromResource(R.xml.preferences);


            ListPreference listPreference = (ListPreference) getPreferenceManager().findPreference("key_stored_list_alarm_logic");
            listPreference.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener (){
                public boolean onPreferenceChange (Preference preference, Object object){
                    //toast.show();
                    return true;
                }
            });







        }

    }


}

