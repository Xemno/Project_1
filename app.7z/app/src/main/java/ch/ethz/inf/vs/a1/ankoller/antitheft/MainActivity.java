package ch.ethz.inf.vs.a1.ankoller.antitheft;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Toast;
import android.widget.ToggleButton;





public class MainActivity extends AppCompatActivity  {
    private ToggleButton toggle;
    private Context context;
    public SharedPreferences preferences;
    public SharedPreferences.Editor preferenceseditor;
    String ACTIVITY_TAG= " **logmessage**";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        context= getApplication();
        //start service
        //startService(new Intent(MyActivity.this, MyService.class)); --> my activity is the MainActivity --> this
        //myService is the AntitheftService
        //stopService(new Intent(this,AntiTheftService.class));


        toggle = (ToggleButton) findViewById(R.id.togglebutton);
        //Create notificationmanager
        //notification should only disappear when the service is shut down
        //used for resuming of the MainActivity
        //unlocking device (turn off alarm) should lead to cancellation of notification



    }

    //public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
      //  if (isChecked) {
            //toggle enabled --> startservice
      //  } else {
            //toggle is disabled--> stopservice

        //}
    //}
        public void onCheckedChanged (View v){
            if (toggle.isChecked()){
                // start service => alarm is on
                startService(new Intent(this, AntiTheftService.class));
            }
            else {
                // stop service => alarm is off
                resetactualstate();
                stopService(new Intent(this, AntiTheftService.class));
            }
        }
    private BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            toggle.setChecked(false);
        }
    };


    public void onResume(){
        super.onResume();
        restoreactualstate();
        LocalBroadcastManager.getInstance(this).registerReceiver(broadcastReceiver, new IntentFilter("AntiTheftService_end"));


    }

    public void onPause() {
        super.onPause();
        setButtonState(toggle.isChecked());
        LocalBroadcastManager.getInstance(this).unregisterReceiver(broadcastReceiver);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        //MenuInflater inflater = getMenuInflater();
       // inflater.inflate(R.menu.game_menu, menu);
        return true;
    }
    public boolean onOptionsItemSelected (MenuItem item){
        switch (item.getItemId()){
            case R.id.menu_settings:
                if (toggle.isChecked()){
                    Toast.makeText(getApplicationContext(), "Disable service to access settings.", Toast.LENGTH_LONG).show();
                }
                else {
                    Intent iSettings = new Intent(this, SettingsActivity.class);
                    this.startActivity(iSettings);
                }
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    //methods for state savings and restoring implemented with preferences
    public void restoreactualstate() {
        SharedPreferences preferences= PreferenceManager.getDefaultSharedPreferences(context);
        boolean prefbool= preferences.getBoolean("btnstate", false);
        //getBoolean (string key def name, bool default value)
        toggle.setChecked(prefbool);
        Log.d(ACTIVITY_TAG,"restored");
        //todo with preferences
    }

    public void resetactualstate(){
        SharedPreferences preference= PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor preferenceseditor= preferences.edit();
        preferenceseditor.putBoolean("btnstate",false);
        preferenceseditor.commit();
    }



    public void setButtonState(boolean btnstate){
        SharedPreferences preferences= PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean("btnstate", btnstate);
        //btnstate is the bool toggle.isCHecked()
        editor.commit();
        //commit your preferences changes back from this editor to the shared
        //preference object it is editing
    }

    public boolean getButtonState(){
        return preferences.getBoolean("btnstate", false);
    }












    }


// toggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        //if (isChecked) {
                // The toggle is enabled
          //      } else {
                // The toggle is disabled
            //    }
              //  }
                //});