package ch.ethz.inf.vs.a1.ankoller.antitheft;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.IBinder;
import android.preference.PreferenceManager;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.content.SharedPreferencesCompat;
import android.util.Log;

public class AntiTheftService extends Service implements AlarmCallback {
    NotificationManager mNotificationManager;
    boolean running;
    int notifyId=1;
    private Context context= getApplication(); //returns the application that
    //owns this activity
    //sharedpreferencesfragment
    private SharedPreferences preferences;
    private SharedPreferences.Editor preferenceseditor;
    private PreferenceManager sharedPreferences;
    String ACTIVITY_TAG = "### Activitytag ###";
    int delay= 2000; //just a number (ms) to wait  thus 2s
    int sensitivity;
    protected static Phoneunlock phoneUnlock;
    private SensorManager mSensorManager;
    private Sensor mSensor;
    SpikeMovementDetector smd;


    public void onCreate(){
    super.onCreate();
    mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationCompat.Builder mNotifyBuilder =  (NotificationCompat.Builder) new NotificationCompat.Builder(this)
                //Set the small icon to use in the notification layouts
                //.setSmallIcon(R.drawable.ic_stat_name)
                .setSmallIcon(R.drawable.ic_stat_name)
                .setContentTitle("Antitheft")
                .setContentText("AntiTheftService")
                // notification used for resuming of MainActivity
                //pendingintent. getactivity (Context context, int requestcode, Intent intetnt, int flags)
                .setContentIntent(PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),0))
                .setOngoing(true); //ongoing notification

        mNotificationManager.notify(notifyId, mNotifyBuilder.build());


        //get application from context
        context= getApplication();

        //service should only disappear when service is shut down
        //unlocking device (turn off alarm) should leed to termination of the service and the cancellation of the notification
        //method to stop action when unlocking device
        phoneUnlock= new Phoneunlock();
        //registerReceiver(phoneUnlock, new IntentFilter(("android.intent.action.USER_PRESENT"));



    // to stop the thread when the device unlocks


        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        //get sensitivity, and delay
        sensitivity = Integer.parseInt(sharedPreferences.getString("key_stored_integer_sensitivity", "1"));
        delay = Integer.parseInt(sharedPreferences.getString("key_stored_integer_delay", "0"));
        int n= Integer.parseInt(sharedPreferences.getString("key_stored_list_alarm_logic","1"));


        mSensorManager=(SensorManager)getSystemService(Context.SENSOR_SERVICE);
        mSensor=mSensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);
        smd= new SpikeMovementDetector(this, sensitivity);
        if(mSensor!=null){
            mSensorManager.registerListener(smd,mSensor, SensorManager.SENSOR_DELAY_NORMAL);

        }else{
            //nothing
        }




    }
    public AntiTheftService() {
        //onDelayStarted() method from AlarmCallback is implemented from the
        //movement detector
        // service should run in the background and post an ongoing notification wich
        //cannot be cleared by the user
        //this notification only disappears when the service is shut down
        //notification used for resuming of the MainActivity
        //unlocking the device (turning off the alarm) should lead to the termination of the service and the cancellation of the
        //notification
    }
    public void onDelayStarted(){
        if(!running){
            running=true;

        }try {
            Thread.sleep(delay); // wait delay seconds
        } catch (InterruptedException e) {
            e.printStackTrace();
            Log.d(ACTIVITY_TAG, "Couldn't sleep");

        }
    }
    private void sendATSFBroadcast() {
        LocalBroadcastManager.getInstance(this).sendBroadcast(new Intent("AntiTheftService_Finished"));
    }

    //stop when the phone unlocks
    public class Phoneunlock extends BroadcastReceiver{

        @Override
        public void onReceive(Context context, Intent intent) {
            if(intent.getAction().equals(Intent.ACTION_USER_PRESENT)){
                sendBroadcast(new Intent ("Phone_unlocked"));

                sendATSFBroadcast();
                //unlock device should terminate service and cancel notification
                stopSelf();
            }
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        return null;
    }
}
