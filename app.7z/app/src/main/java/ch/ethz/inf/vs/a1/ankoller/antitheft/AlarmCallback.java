package ch.ethz.inf.vs.a1.ankoller.antitheft;

public interface AlarmCallback {
    void onDelayStarted();
}
